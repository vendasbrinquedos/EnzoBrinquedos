fetch('produtos.json')
  .then(response => response.json())
  .then(produtos => {
    const container = document.getElementById('lista-produtos');
    container.innerHTML = '';

    produtos.forEach(produto => {
      const div = document.createElement('div');
      div.classList.add('produto');
      div.innerHTML = `
        <img src="${produto.imagem}" alt="${produto.nome}">
        <h3>${produto.nome}</h3>
        <p>${produto.descricao}</p>
        <p>R$ ${produto.preco.toFixed(2)}</p>
      `;
      container.appendChild(div);
    });
  })
  .catch(error => console.error('Erro ao carregar produtos:', error));